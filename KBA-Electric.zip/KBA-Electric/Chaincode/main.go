package main

import (
	"log"

	"github.com/kba-chf/kba-automobile/chaincode/contracts"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
	//"github.com/hyperledger/fabric-contract-api-go/contractapi"
	//"github.com/kba-chf/kba-automobile/chaincode/contracts"
	//"/home/npci-admin/KBA-CHF/KBA-Elecric/Chaincode"
)

func main() {
	electricContract := new(contracts.ElectricContract)
	OrderContract := new(contracts.OrderContract)
	chaincode, err := contractapi.NewChaincode(electricContract, OrderContract)

	if err != nil {
		log.Panicf("Could not create chaincode." + err.Error())
	}

	err = chaincode.Start()

	if err != nil {
		log.Panicf("Failed to start chaincode. " + err.Error())
	}
}
