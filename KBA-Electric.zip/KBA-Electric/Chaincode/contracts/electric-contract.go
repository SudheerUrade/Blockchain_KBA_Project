package contracts

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

// ElectricContract contract for managing CRUD for Electric
type ElectricContract struct {
	contractapi.Contract
}

type PaginatedQueryResult struct {
	Records             []*Electric `json:"records"`
	FetchedRecordsCount int32       `json:"fetchedRecordsCount"`
	Bookmark            string      `json:"bookmark"`
}

type HistoryQueryResult struct {
	Record    *Electric `json:"record"`
	TxId      string    `json:"txId"`
	Timestamp string    `json:"timestamp"`
	IsDelete  bool      `json:"isDelete"`
}

type Electric struct {
	AssetType         string `json:"AssetType"`
	ElectricId        string `json:"ElectricId"`
	ElectricType      string `json:"ElectricType"`
	DateOfManufacture string `json:"DateOfManufacture"`
	OwnedBy           string `json:"OwnedBy"`
	DateOfExpiry      string `json:"DateOfExpiry"`
	ElectricName      string `json:"ElectricName"`
	Status            string `json:"Status"`
}

type EventData struct {
	Type  string
	Model string
}

// ElectricExists returns true when asset with given ID exists in world state
func (c *ElectricContract) ElectricExists(ctx contractapi.TransactionContextInterface, electricID string) (bool, error) {
	data, err := ctx.GetStub().GetState(electricID)

	if err != nil {
		return false, fmt.Errorf("failed to read from world state: %v", err)

	}
	return data != nil, nil
}

// CreateElectric creates a new instance of Electric
func (c *ElectricContract) CreateElectric(ctx contractapi.TransactionContextInterface, electricID string, dateofexpiry string, electricname string, electricdype string, manufacturerName string, dateOfManufacture string) (string, error) {
	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return "", err
	}

	// if clientOrgID == "Org1MSP" {
	// if clientOrgID == "producer-electric-com" {
	if clientOrgID == "ProducerMSP" {
		exists, err := c.ElectricExists(ctx, electricID)
		if err != nil {
			return "", fmt.Errorf("could not read from world state. %s", err)
		} else if exists {
			return "", fmt.Errorf("the asset %s already exists", electricID)
		}

		electric := Electric{
			AssetType:         "electric",
			ElectricId:        electricID,
			ElectricType:      electricdype,
			DateOfManufacture: dateOfManufacture,
			DateOfExpiry:      dateofexpiry,
			ElectricName:      electricname,
			OwnedBy:           manufacturerName,
			Status:            "In Factory",
		}

		fmt.Println("Create electric data ======= ", electric)
		bytes, _ := json.Marshal(electric)

		err = ctx.GetStub().PutState(electricID, bytes)
		if err != nil {
			return "", err
		} else {
			addElectricEventData := EventData{
				Type:         "Electric creation",
				ElectricType: electrictype,
			}
			eventDataByte, _ := json.Marshal(addElectricEventData)
			ctx.GetStub().SetEvent("CreateElectric", eventDataByte)

			return fmt.Sprintf("successfully added electric %v", electricID), nil
		}

	} else {
		return "", fmt.Errorf("user under following MSPID: %v can't perform this action", clientOrgID)
	}

}

// ReadElectric retrieves an instance of Electric from the world state
func (c *ElectricContract) ReadElectric(ctx contractapi.TransactionContextInterface, electricID string) (*Electric, error) {
	exists, err := c.ElectricExists(ctx, electricID)
	if err != nil {
		return nil, fmt.Errorf("could not read from world state. %s", err)
	} else if !exists {
		return nil, fmt.Errorf("the asset %s does not exist", electricID)
	}

	bytes, _ := ctx.GetStub().GetState(electricID)

	electric := new(Electric)

	err = json.Unmarshal(bytes, &electric)

	if err != nil {
		return nil, fmt.Errorf("could not unmarshal world state data to type Electric")
	}

	return electric, nil
}

// DeleteElectric removes the instance of Electric from the world state
func (c *ElectricContract) DeleteElectric(ctx contractapi.TransactionContextInterface, electricID string) (string, error) {

	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return "", err
	}
	// if clientOrgID == "Org1MSP" {
	// if clientOrgID == "producer-electric-com" {
	if clientOrgID == "ProducerMSP" {
		exists, err := c.ElectricExists(ctx, electricID)
		if err != nil {
			return "", fmt.Errorf("could not read from world state. %s", err)
		} else if !exists {
			return "", fmt.Errorf("the asset %s does not exist", electricID)
		}

		err = ctx.GetStub().DelState(electricID)
		if err != nil {
			return "", err
		} else {
			return fmt.Sprintf("electric with id %v is deleted from the world state.", electricID), nil
		}

	} else {
		return "", fmt.Errorf("user under following MSP:%v cannot able to perform this action", clientOrgID)
	}
}

// GetElectricsByRange gives a range of asset details based on a start key and end key
func (c *ElectricContract) GetElectricsByRange(ctx contractapi.TransactionContextInterface, startKey, endKey string) ([]*Electric, error) {
	resultsIterator, err := ctx.GetStub().GetStateByRange(startKey, endKey)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	return electricResultIteratorFunction(resultsIterator)
}

func (c *ElectricContract) GetElectricHistory(ctx contractapi.TransactionContextInterface, electricID string) ([]*HistoryQueryResult, error) {

	resultsIterator, err := ctx.GetStub().GetHistoryForKey(electricID)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	var records []*HistoryQueryResult
	for resultsIterator.HasNext() {
		response, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}

		var electric Electric
		if len(response.Value) > 0 {
			err = json.Unmarshal(response.Value, &electric)
			if err != nil {
				return nil, err
			}
		} else {
			electric = Electric{
				ElectricId: electricID,
			}
		}

		timestamp := response.Timestamp.AsTime()

		formattedTime := timestamp.Format(time.RFC1123)

		record := HistoryQueryResult{
			TxId:      response.TxId,
			Timestamp: formattedTime,
			Record:    &electric,
			IsDelete:  response.IsDelete,
		}
		records = append(records, &record)
	}

	return records, nil
}

func (c *ElectricContract) GetAllElectrics(ctx contractapi.TransactionContextInterface) ([]*Electric, error) {

	queryString := `{"selector":{"AssetType":"electric"}, "sort":[{ "ElectricId": "desc"}]}`

	resultsIterator, err := ctx.GetStub().GetQueryResult(queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()
	return electricResultIteratorFunction(resultsIterator)
}

func (c *ElectricContract) GetElectricsWithPagination(ctx contractapi.TransactionContextInterface, pageSize int32, bookmark string) (*PaginatedQueryResult, error) {
	queryString := `{"selector":{"AssetType":"electric"}}`
	resultsIterator, responseMetadata, err := ctx.GetStub().GetQueryResultWithPagination(queryString, pageSize, bookmark)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	electrics, err := electricResultIteratorFunction(resultsIterator)
	if err != nil {
		return nil, err
	}

	return &PaginatedQueryResult{
		Records:             electrics,
		FetchedRecordsCount: responseMetadata.FetchedRecordsCount,
		Bookmark:            responseMetadata.Bookmark,
	}, nil
}

// Iterator function
func electricResultIteratorFunction(resultsIterator shim.StateQueryIteratorInterface) ([]*Electric, error) {
	var electrics []*Electric
	for resultsIterator.HasNext() {
		queryResult, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		var electric Electric
		err = json.Unmarshal(queryResult.Value, &electric)
		if err != nil {
			return nil, err
		}
		electrics = append(electrics, &electric)
	}

	return electrics, nil
}

// GetMatchingOrders get matching orders for electric from the orders
func (c *ElectricContract) GetMatchingOrders(ctx contractapi.TransactionContextInterface, electricID string) ([]*Order, error) {
	exists, err := c.ElectricExists(ctx, electricID)
	if err != nil {
		return nil, fmt.Errorf("could not read from world state. %s", err)
	} else if !exists {
		return nil, fmt.Errorf("the asset %s does not exist", electricID)
	}

	electric, err := c.ReadElectric(ctx, electricID)
	if err != nil {
		return nil, fmt.Errorf("error reading electric %v", err)
	}
	queryString := fmt.Sprintf(`{"selector":{"assetType":"Order","dateofexpiry":"%s", "electricname": "%s", "electricdype":"%s"}}`, electric.DateOfExpiry, electric.ElectricName, electric.ElectricType)
	resultsIterator, err := ctx.GetStub().GetPrivateDataQueryResult(collectionName, queryString)

	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	return OrderResultIteratorFunction(resultsIterator)

}

// MatchOrder matches electric with matching order
func (c *ElectricContract) MatchOrder(ctx contractapi.TransactionContextInterface, electricID string, orderID string) (string, error) {

	bytes, err := ctx.GetStub().GetPrivateData(collectionName, orderID)
	if err != nil {
		fmt.Println("Could not get ptivate data")
	}
	order := new(Order)

	err = json.Unmarshal(bytes, order)

	if err != nil {
		fmt.Println("Could not get ptivate data")
	}

	if err != nil {
		return "", err
	}

	electric, err := c.ReadElectric(ctx, electricID)
	if err != nil {
		return "", err
	}

	if electric.DateOfExpiry == order.DateOfExpiry && electric.ElectricType == order.ElectricType && electric.ElectricName == order.ElectricName {
		electric.OwnedBy = order.SupplierName
		electric.Status = "assigned to a dealer"
		bytes, _ := json.Marshal(electric)
		ctx.GetStub().DelPrivateData(collectionName, orderID)
		err = ctx.GetStub().PutState(electricID, bytes)
		if err != nil {
			return "", err
		} else {
			return fmt.Sprintf("Deleted order %v and Assigned %v to %v", orderID, electric.ElectricId, order.SupplierName), nil
		}
	} else {
		return "", fmt.Errorf("order is not matching")
	}
}

// RegisterElectric register electric to the buyer
func (c *ElectricContract) RegisterElectric(ctx contractapi.TransactionContextInterface, electricID string, ownerName string, registrationNumber string) (string, error) {
	clientOrgID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return "", err
	}

	// if clientOrgID == "Org3MSP" {
	// if clientOrgID == "retailer.electric-com" {
	if clientOrgID == "RetailerMSP" {

		exists, err := c.ElectricExists(ctx, electricID)
		if err != nil {
			return "", fmt.Errorf("could not read from world state. %s", err)
		}
		if exists {
			electric, _ := c.ReadElectric(ctx, electricID)
			electric.Status = fmt.Sprintf("Registered to  %v with plate number %v", ownerName, registrationNumber)
			electric.OwnedBy = ownerName

			bytes, _ := json.Marshal(electric)
			err = ctx.GetStub().PutState(electricID, bytes)
			if err != nil {
				return "", err
			} else {
				return fmt.Sprintf("Electric %v successfully registered to %v", electricID, ownerName), nil
			}

		} else {
			return "", fmt.Errorf("electric %v does not exist", electricID)
		}

	} else {
		return "", fmt.Errorf("user under following MSPID: %v cannot able to perform this action", clientOrgID)
	}

}
