package main

import "fmt"

func main() {

	// use this functions to evaluate and submit txns
	// try calling these functions

	// result := submitTxnFn(
	// 	"manufacturer",
	// 	"electricchannel",
	// 	"KBA-Electric",
	// 	"CarContract",
	// 	"invoke",
	// 	make(map[string][]byte),
	// 	"CreateCar",
	// 	"Car-09",
	// 	"Tata",
	// 	"Harrier",
	// 	"Black",
	// 	"fac01",
	// 	"25/10/2023",
	// )

	// privateData := map[string][]byte{
	// 	"AssetType":    []byte("LG"),
	// 	"ElectricType": []byte("DELL"),
	// 	"SupplierName": []byte("White"),
	// 	"DateOfExpiry": []byte("XXX"),
	// 	"ElectricName": []byte("XXX"),
	// 	"OrderID":      []byte("XXX"),
	// }

	result := submitTxnFn("producer", "electricchannel", "KBA-Electric", "ElectricContract", "invoke", make(map[string][]byte), "CreateElectric", "ID-04", "3333", "xXXX", "XXXX", "XXXX", "XXXXX")
	//result1 := submitTxnFn("dealer", "electricchannel", "KBA-Electric", "OrderContract", "query", make(map[string][]byte), "ReadOrder", "ORD-03")
	//result2 := submitTxnFn("producer", "electricchannel", "KBA-Electric", "ElectricContract", "query", make(map[string][]byte), "GetAllElectrics")
	// result3 := submitTxnFn("manufacturer", "electricchannel", "KBA-Electric", "OrderContract", "query", make(map[string][]byte), "GetAllOrders")
	// result4 := submitTxnFn("manufacturer", "electricchannel", "KBA-Electric", "CarContract", "query", make(map[string][]byte), "GetMatchingOrders", "Car-06")
	// result5 := submitTxnFn("manufacturer", "electricchannel", "KBA-Electric", "CarContract", "invoke", make(map[string][]byte), "MatchOrder", "Car-06", "ORD-01")
	// result6 := submitTxnFn("mvd", "electricchannel", "KBA-Electric", "CarContract", "invoke", make(map[string][]byte), "RegisterCar", "Car-06", "Dani", "KL-01-CD-01")
	fmt.Println(result)
	// fmt.Println(result1)
	// fmt.Println(result2)
	// fmt.Println(result3)
	// fmt.Println(result4)
	// fmt.Println(result5)
	// fmt.Println(result6)
}
