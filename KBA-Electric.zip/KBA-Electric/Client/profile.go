package main

// Config represents the configuration for a role.
type Config struct {
	CertPath     string `json:"certPath"`
	KeyDirectory string `json:"keyPath"`
	TLSCertPath  string `json:"tlsCertPath"`
	PeerEndpoint string `json:"peerEndpoint"`
	GatewayPeer  string `json:"gatewayPeer"`
	MSPID        string `json:"mspID"`
}

// Create a Profile map
var profile = map[string]Config{

	"producer": {
		CertPath:     "../Electric-network/organizations/peerOrganizations/producer.electric.com/users/User1@producer.electric.com/msp/signcerts/cert.pem",
		KeyDirectory: "../Electric-network/organizations/peerOrganizations/producer.electric.com/users/User1@producer.electric.com/msp/keystore/",
		TLSCertPath:  "../Electric-network/organizations/peerOrganizations/producer.electric.com/peers/peer0.producer.electric.com/tls/ca.crt",
		PeerEndpoint: "localhost:7051",
		GatewayPeer:  "peer0.producer.electric.com",
		MSPID:        "ProducerMSP",
	},

	"supplier": {
		CertPath:     "../Electric-network/organizations/peerOrganizations/supplier.electric.com/users/User1@supplier.electric.com/msp/signcerts/cert.pem",
		KeyDirectory: "../Electric-network/organizations/peerOrganizations/supplier.electric.com/users/User1@supplier.electric.com/msp/keystore/",
		TLSCertPath:  "../Electric-network/organizations/peerOrganizations/supplier.electric.com/peers/peer0.supplier.electric.com/tls/ca.crt",
		PeerEndpoint: "localhost:9051",
		GatewayPeer:  "peer0.supplier.electric.com",
		MSPID:        "SupplierMSP",
	},

	"wholesaler": {
		CertPath:     "../Electric-network/organizations/peerOrganizations/wholesaler.electric.com/users/User1@wholesaler.electric.com/msp/signcerts/cert.pem",
		KeyDirectory: "../Electric-network/organizations/peerOrganizations/wholesaler.electric.com/users/User1@wholesaler.electric.com/msp/keystore/",
		TLSCertPath:  "../Electric-network/organizations/peerOrganizations/wholesaler.electric.com/peers/peer0.wholesaler.electric.com/tls/ca.crt",
		PeerEndpoint: "localhost:11051",
		GatewayPeer:  "peer0.wholesaler.electric.com",
		MSPID:        "WholesalerMSP",
	},
	"retailer": {
		CertPath:     "../Electric-network/organizations/peerOrganizations/retailer.electric.com/users/User1@retailer.electric.com/msp/signcerts/cert.pem",
		KeyDirectory: "../Electric-network/organizations/peerOrganizations/retailer.electric.com/users/User1@retailer.electric.com/msp/keystore/",
		TLSCertPath:  "../Electric-network/organizations/peerOrganizations/retailer.electric.com/peers/peer0.retailer.electric.com/tls/ca.crt",
		PeerEndpoint: "localhost:12051",
		GatewayPeer:  "peer0.retailer.electric.com",
		MSPID:        "RetailerMSP",
	},
}
