package main

func main() {

	// blockEventListener("manufacturer", "autochannel")
	chaincodeEventListener("producer", "electronicchannel", "KBA-Electronic")
	// pvtBlockEventListener("manufacturer", "autochannel")

}